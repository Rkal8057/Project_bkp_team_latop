import React from 'react';
import { Route, Routes } from "react-router-dom";
import Login from '../app/pages/login/Login'; // Correct the casing here
import Signup from '../app/pages/signup/Signup';
import Dashboard from '../app/pages/dashboard/Dashboard';
import Error from '../app/pages/error/Error';
import LogHistory from '../app/pages/logHistory/LogHistory';
import UploadFile from '../app/pages/UploadFile/UploadFile';

function Router() {


  return (
    <>
      <Dashboard>
        <Routes>
          <Route exact path='/' element={< Login />} />
          <Route exact path='/loghistory' element={<LogHistory />} />
          <Route exact path='/signup' element={< Signup />} />
          <Route exact path='/upload' element={< UploadFile />} />
          <Route exact path='*' element={<Error />} />
        </Routes>
      </Dashboard>

    </>
  );
}
export default Router;







