const PaginationSetting = {
    recordsPerPage: 10,
    totalPages: 0,
    totalRecords: 0
}

module.exports = PaginationSetting;