import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useNavigate ,NavLink} from "react-router-dom";
import {login } from '../../api/user';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { loginSuccess } from '../../../redux/actions/user';

const Login = (props) => {

    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        email: "",
        password: ""
    });

    //onchange input field
    const handleChange = (e) => {
        const { value, name } = e.target;
        setFormData({ ...formData, [name]: value.trim() });
    }
    
    //form submit on login 
    const handleSubmit = (e) => {
        e.preventDefault();

        if (!formData.email) {
            toast.error("Please enter email");
            return;
        }
        else if (formData.email && !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(formData.email)) {
            toast.error("Please enter valid email address");
            return;
        }
        else if (!formData.password) {
            toast.error("Please enter password");
            return;
        }

        setLoading(true);
        let params = {
            email: formData.email.trim(),
            password: formData.password,
        }

        props.login(params, res => {
            setLoading(false);
            if (res.status == true) {
                toast.success(res.message);

                let userData = {
                    token: res.data.authToken
                }
                props.onLoginSuccess(userData);
                navigate("/upload");     
            }
            else {
                toast.error(res.message);
            }
        },
            err => {
                setLoading(false);
                toast.error(err.message);
            }
        )
    }

    return (
        <>
            <div className="bg-gray-100 flex items-center justify-center h-screen">
                <div className="bg-white w-full max-w-sm p-6 rounded-lg shadow-md">
                    <h2 className="text-3xl font-semibold mb-4 text-center">Welcome back!</h2>
                    <form>
                        <div className="mb-4">
                            <label for="email" className="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" id="email" name="email"
                                className="mt-1 p-2 w-full border rounded-md focus:outline-none focus:ring focus:border-blue-300"
                                value={formData.email}
                                onChange={(e) => { handleChange(e) }}
                            />
                        </div>
                        <div className="mb-6">
                            <label for="password" className="block text-sm font-medium text-gray-700">Password</label>
                            <input type="password" id="password" name="password"
                                className="mt-1 p-2 w-full border rounded-md focus:outline-none focus:ring focus:border-blue-300"
                                value={formData.password}
                                onChange={(e) => { handleChange(e) }} />
                        </div>
                        <button type="submit"
                            onClick={(e) => { handleSubmit(e) }}
                            className="bg-blue-500 text-white p-2 rounded w-full hover:
                        bg-blue-600 focus:outline-none focus:ring focus:border-blue-300">
                        {loading ? "Loading..." : "Log in"}          
                        </button>
                    </form>
                
                    <p className="text-center mt-4 text-sm text-gray-600">
                        Don't have an account? <NavLink to="/signup" className="text-blue-500">Sign Up now</NavLink>
                    </p>
                </div>
            </div>
        </>
    )
}


const mapStateToProps = state => ({
    // auth: state.auth
});

const mapDispatchToProps = dispatch => ({
    login: bindActionCreators(login, dispatch),
    onLoginSuccess : payload => dispatch(loginSuccess(payload)),
});

// export default Login
export default connect(mapStateToProps, mapDispatchToProps)(Login);
