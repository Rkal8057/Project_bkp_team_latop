import React, { useState } from 'react'
import { useNavigate, NavLink } from "react-router-dom";

const Header = () => {
    return (
        <>
            <header className="bg-gray-800 text-white py-4">
                <div className="container mx-auto flex justify-between items-center">
                    <h1 className="text-2xl font-semibold">Your App Name</h1>
                    <nav>
                        <ul className="flex space-x-4">
                            <li>
                                <NavLink to="/upload"  className="hover:underline">Sign Up now</NavLink>
                            </li>
                            <li>
                                <NavLink to="/loghistory" className="hover:underline">Show Log History</NavLink>
                            </li>
                        </ul>
                    </nav>
                </div>
            </header>
        </>

    )
}

export default Header