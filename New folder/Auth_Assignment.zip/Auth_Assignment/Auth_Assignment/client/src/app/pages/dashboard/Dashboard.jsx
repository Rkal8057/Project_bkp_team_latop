import React, { useState } from 'react'
import { useNavigate, NavLink, Link } from "react-router-dom";
import Header from '../header/Header';
import { useLocation } from 'react-router-dom';


function Dashboard({ children }) {
    const pathName = window.location.pathname;

    const location = useLocation();
    const currentURL = location.pathname;

    // console.log(currentURL,"currentURLcurrentURLcurrentURL")

    const authRoutes = ["/", "/signup"];


    console.log(children,"children @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

    return (
        <>
            <div className="wrapper">
                {!authRoutes.includes(pathName) ? (
                    <>
                        <Header/>
                        {children}
                    </>
                ) : (
                    <>
                        <main className="p-8">
                            {children}
                        </main>
                    </>
                )}
            </div>
        </>
    )
}

export default Dashboard