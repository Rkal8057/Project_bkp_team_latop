import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useNavigate, NavLink } from "react-router-dom";

import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { uploadFile } from '../../api/user';

const UploadFile = (props) => {


    const [selectedFile, setSelectedFile] = useState(null);
    const [fileData, setFileData] = useState();

    const handleFileChange = (e) => {
        setSelectedFile(e.target.files[0]);
    };

    const handleUpload = (e) => {
        e.preventDefault();


        if (!selectedFile) {
            toast.error("Please select the file");
            return;
        }

        const formData = new FormData();
        formData.append('file', selectedFile)

        let params = {
            token: props.user.token,
            formData: formData
        }

        props.uploadFile(params, res => {
            if (res.status == true) {
                toast.success(res.message);
                setFileData(res.data.text)
            }
            else {
                toast.error(res.message);
            }
        },
            err => {
                toast.error(err.message);
            }
        )

    }

    return (
        <>
            <div className="bg-gray-100 min-h-screen flex flex-col items-center justify-top">
                <div className="bg-white p-8 rounded shadow-md mb-8 w-96">
                    <h1 className="text-2xl font-semibold mb-4">Upload a File</h1>
                    <form action="/upload" method="post" encType="multipart/form-data">
                        <div className="mb-4">
                            <label htmlFor="fileInput" className="block text-gray-700 font-medium mb-2">Select a File:</label>
                            <input
                                type="file"
                                name="file"
                                id="fileInput"
                                className="border p-2 w-full"
                                onChange={(e) => { handleFileChange(e) }}
                            />
                        </div>
                        <button
                            type="submit"
                            onClick={(e) => { handleUpload(e) }}
                            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                        >
                            Upload
                        </button>
                    </form>
                </div>

                <div className="bg-white p-8 rounded shadow-md w-96">
                    <h1 className="text-2xl font-semibold mb-4">Uploaded Data</h1>
                    <ul>
                        {fileData}
                    </ul>
                </div>
            </div>

            {/* 
            <div className="bg-gray-100 h-screen flex items-center justify-center">
                <div className="bg-white p-8 rounded shadow-md w-96">
                    <h1 className="text-2xl font-semibold mb-4">Upload a File</h1>
                    <form action="/upload" method="post" enctype="multipart/form-data">
                        <div className="mb-4">
                            <label for="fileInput" className="block text-gray-700 font-medium mb-2">Select a File:</label>
                            <input type="file" name="file" id="fileInput" className="border p-2 w-full"
                                onChange={(e) => { handleFileChange(e) }}

                            />
                        </div>
                        <button type="submit"
                            onClick={(e) => { handleUpload(e) }}
                            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                        >Upload</button>
                    </form>
                </div>
            </div>

            <div className="bg-white p-8 rounded shadow-md">
                <h1 className="text-2xl font-semibold mb-4">Uploaded Data</h1>
                <ul>{fileData}</ul>
            </div> */}
        </>
    )
}


const mapStateToProps = state => ({
    user: state.user
});

const mapDispatchToProps = dispatch => ({
    uploadFile: bindActionCreators(uploadFile, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(UploadFile);