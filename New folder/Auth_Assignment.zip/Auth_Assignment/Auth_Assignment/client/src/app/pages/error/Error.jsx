import React from 'react'

function Error() {
    return (
        <>
            <div class="bg-gray-100 flex items-center justify-center h-screen">
                <div class="bg-white w-full max-w-sm p-6 rounded-lg shadow-md">
                    <h2 class="text-3xl font-semibold mb-4 text-center">Oops! Something went wrong</h2>
                    <p class="text-center text-gray-700">We're sorry, but an error occurred while processing your request.</p>
                    <div class="mt-6 text-center">
                    </div>
                </div>
            </div>
        </>
    )
}

export default Error