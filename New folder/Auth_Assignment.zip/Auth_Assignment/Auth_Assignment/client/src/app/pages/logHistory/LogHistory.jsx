import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'react-toastify';
// import { useNavigate ,NavLink} from "react-router-dom";
import { GetLog } from '../../api/user';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";


const HistoryPage = (props) => {

    let [data, setData] = useState();

    let params = {
        token: props.user.token
    }

    let count  =1
    const fetchData = async () => {
        
        props.GetLog(params, res => {
            if (res.status == true) {
                toast.success(res.message);
                setData(res.data)
            }
            else {
                toast.error(res.message);
            }
        },
            err => {
                toast.error(err.message);
            }
        )
    };

    // useEffect(() => {
    //     console.count(count)
    //     if(!data){
    //         fetchData();
    //     }
    //     // count++

       
    // }, [data]);

    useEffect(() => {
        console.log(count)
        if(count ==1){
            fetchData();
        }
        count++
    }, []);

    return (

        
        <div className="bg-gray-100 h-screen p-8">
            <div className="bg-white p-8 rounded shadow-md">
                <h1 className="text-2xl font-semibold mb-4">History of Upload File</h1>
                <table className="min-w-full">
                    <thead>
                        <tr>
                            <th className="text-left py-2">userId</th>
                            <th className="text-left py-2">fileName</th>
                            <th className="text-left py-2">extensionType</th>
                            {/* <th className="text-left py-2">locationPath</th> */}
                            <th className="text-left py-2">description</th>
                            <th className="text-left py-2">status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data && data.map((data) => {
                                return (
                                    <>
                                        <tr>
                                            <td className="py-2">{data.userId}</td>
                                            <td className="py-2">{data.fileName}</td>
                                            <td className="py-2">{data.extensionType}</td>
                                            {/* <td className="py-2">J{data.locationPath}</td> */}
                                            <td className="py-2">{data.description}</td>
                                            <td className="py-2">{data.status}</td>
                                        </tr>
                                    </>
                                )
                            })
                        }

                    </tbody>
                </table>
            </div>
        </div>
    );
};

const mapStateToProps = state => ({
    user: state.user
});

const mapDispatchToProps = dispatch => ({
    GetLog: bindActionCreators(GetLog, dispatch),
});

// export default Login
export default connect(mapStateToProps, mapDispatchToProps)(HistoryPage);
