import RestClient from '../../utilities/RestClient';
import Message from '../constants/message';
let AUTH_API_URL=  "http://127.0.0.1:8000"


const getApiResponseMessage = (response, defaultErrorMessage = 'Something went wrong!') => {

    let responseMessage = defaultErrorMessage;
    let payload = response;   // response.data // Data returned by API

    if (payload && Array.isArray(payload) && payload.length > 0) {
        responseMessage = payload[0];
    }
    else if (response.msg) {
        responseMessage = response.msg;
    }
    return responseMessage;
}
  
const getApiResponse = (result, responseMessage) => {
    let res = {};
    if (result.status === 200 || result.status === 201) {
        console.log("if condition")
        res = {
        status: true,
        message: responseMessage,
        statusCode: result.status,
        type: Message.success,
        data: result.data.data
        };
    } else {
        console.log("else condition")
        res = {
        status: false,
        message: responseMessage,
        type: Message.error,
        statusCode: result.status
        };
    }
    return res;
}
  

export const signup = (params, cb)=>{
    return dispatch =>{
        RestClient.post(`${AUTH_API_URL}/user/signup`, params )
        .then( result => {
            let response = result.data
            let responseMessage = getApiResponseMessage(response)
            let res = getApiResponse ( result , responseMessage)
            cb(res)
        })
        .catch( error => {
            let res = {
                status: false,
                message: Message.commonError,
                type: Message.error
            };
            cb(res);
        })
    }
}


export const login = (params, cb) => {
    console.log("UserApi@login>>>")

  return dispatch=>(
    RestClient.post(`${AUTH_API_URL}/user/login`, params )
    .then( result => {
        let response = result.data
        let responseMessage = getApiResponseMessage(response)
        let res = getApiResponse ( result , responseMessage)
        cb(res)
    })
    .catch( error => {
        let res = {
            status: false,
            message: Message.commonError,
            type: Message.error
        };
        cb(res);
    })
  )
}

export const GetLog = (params, cb)=>{
    console.log("UserApi@GetLog")
    
    return dispatch=>(
        RestClient.get(`${AUTH_API_URL}/log/all`, params )
        .then( result => {
            let response = result.data
            let responseMessage = getApiResponseMessage(response)
            let res = getApiResponse ( result , responseMessage)
            cb(res)
        })
        .catch( error => {
            let res = {
                status: false,
                message: Message.commonError,
                type: Message.error
            };
            cb(res);
        })
    )
}

export const uploadFile = (params, cb) => {
    console.log("UserApi@uploadFile>>>")

  return dispatch=>(
    RestClient.post(`${AUTH_API_URL}/user/uploads/pdf`, params )
    .then( result => {
        let response = result.data
        let responseMessage = getApiResponseMessage(response)
        let res = getApiResponse ( result , responseMessage)
        cb(res)
    })
    .catch( error => {
        let res = {
            status: false,
            message: Message.commonError,
            type: Message.error
        };
        cb(res);
    })
  )
}
