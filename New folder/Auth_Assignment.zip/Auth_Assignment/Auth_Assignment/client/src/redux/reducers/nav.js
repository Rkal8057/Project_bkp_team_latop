// import {
//         OPEN_NAV,
//         CLOSE_NAV
// } from "../actions/types";
  
// const initialState = {

// };


// export default function ( state = initialState, action ) {

//     let type = state

//     switch(state.type){
//         case OPEN_NAV: OPEN_NAV : return { }
//         case CLOSE_NAV: CLOSE_NAV : return { }
//     }
// }