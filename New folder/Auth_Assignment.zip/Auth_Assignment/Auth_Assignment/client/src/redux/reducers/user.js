import {
    LOGIN_SUCCESS,
    SET_PROFILE_DATA,
    LOGIN_FAIL,
    LOGOUT,
} from "../actions/types";
  
const initialState = {
    isLoggedIn: false,
    userProfile: {},
    token: ""
};

export default function ( state = initialState , action){
    const { type, payload } = action;
    switch(type){
        case LOGIN_SUCCESS: 
            return { 
                ...state, 
                isLoggedIn: true,
                // userProfile: payload.userProfile,
                token: payload.token
            }
        case LOGIN_FAIL:  
            return {
                ...state,
                isLoggedIn: false,
                user: null,
            };
        case LOGOUT:
            return {
                ...state,
                isLoggedIn: false,
                userProfile: {},
                token: ""
            };
        case SET_PROFILE_DATA: 
            return {
                ...state,
                userProfile: payload,
            };
        default:
        return state;
    }
}