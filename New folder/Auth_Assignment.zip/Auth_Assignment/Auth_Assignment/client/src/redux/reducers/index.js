import { combineReducers } from "redux";
import user from "./user";
// import Kennel from './Kennel';
// import Client from './client';
// import message from "./message";
// import nav from "./nav";

export default combineReducers({
  user
  // Kennel,
  // Client,
  // message,
  // nav,
});