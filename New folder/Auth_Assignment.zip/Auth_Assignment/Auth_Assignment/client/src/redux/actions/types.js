export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAIL = "LOGIN_FAIL";
export const LOGOUT = "LOGOUT";
export const SET_MESSAGE = "SET_MESSAGE";
export const CLEAR_MESSAGE = "CLEAR_MESSAGE";
export const OPEN_NAV  = "OPEN_NAV";
export const CLOSE_NAV  = "CLOSE_NAV";


// //profile Actions
export const SET_PROFILE_DATA = "SET_PROFILE_DATA";

// export const SET_KENNEL_LIST = "SET_KENNEL_LIST";
// export const SET_DOG_DETAIL = "SET_DOG_DETAIL";
// export const SET_DOG_DETAIL_ID = "SET_DOG_DETAIL_ID";

// export const SET_CLIENT_LIST = "SET_CLIENT_LIST";