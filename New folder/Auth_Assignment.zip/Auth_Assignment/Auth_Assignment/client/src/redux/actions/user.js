import * as TYPE from './types'

export const loginSuccess = (payload) => {
    return {
        type: TYPE.LOGIN_SUCCESS,
        payload: payload
    }
}

// export const setProfileData = (payload) => {
//     return {
//         type: TYPE.SET_PROFILE_DATA,
//         payload: payload

//     }
// }

// export const logout = () => {
//     return {
//         type: TYPE.LOGOUT
//     }
// }


