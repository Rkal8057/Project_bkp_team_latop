import * as TYPE from './types'


// export const openNav = () => {
//   return {
//     type: TYPE.OPEN_NAV,
//   }
// }


// export const closedNav = () => {
//     return {
//         type : TYPE.CLOSE_NAV
//     }
// }