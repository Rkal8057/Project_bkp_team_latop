import axios from 'axios';
const queryString = require('query-string');

/******** Set Authorization token in header ***********/
export const setAuthorizationToken = (axios, token) => {
  if (token) {
    //axios.defaults.headers.common.Authorization = `Bearer ${token}`;
    axios.defaults.headers.common.Authorization = token;
  } else {
    delete axios.defaults.headers.common.Authorization;
  }
};


var config = {
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    // 'Credential': 'same-origin',
  },
};

class RestClient {

  static post(url, params, isAuthRequired = false) {
    // if(isAuthRequired){
    //   config = {...config, withCredentials: true}
    // }
    setAuthorizationToken(axios, params.token);


    if (params.token)
      delete params.token;

      if(params.formData){
        params = params.formData
        config.headers['Content-Type']="multipart/form-data"
      }else{
        params = JSON.stringify(params)
      }
  
    return new Promise(function (fulfill, reject) {
      axios
        .post(url,params, config)
        .then(function (response) {
          fulfill({ status: response.status, data: response.data });
        })
        .catch(function (error) {
          if (error && error.response) {
            fulfill({ status: error.response.status, data: error.response.data });
          } else {
            reject(error);
          }
        });
    });
  }

  static put(url, params, isAuthRequired = false) {
    // if(isAuthRequired){
    //   config = {...config, withCredentials: true}
    // }
    setAuthorizationToken(axios, params.token);
    if (params.token)
      delete params.token;

    return new Promise(function (fulfill, reject) {
      axios
        .put(url, JSON.stringify(params), config)
        .then(function (response) {
          fulfill({ status: response.status, data: response.data });
        })
        .catch(function (error) {
          if (error && error.response) {
            fulfill({ status: error.response.status, data: error.response.data });
          } else {
            reject(error);
          }
        }); 
    });
  }

  static get(url, params, isAuthRequired = false) {
    // if(isAuthRequired){
    //   config = {...config, withCredentials: true}
    // }
    setAuthorizationToken(axios, params.token);
    if (params.token)
      delete params.token;

    // let query = queryString.stringify(params);
    return new Promise(function (fulfill, reject) {
      axios.get(url, config)
      .then(function (response) {
          fulfill({ status: response.status, data: response.data });
        })
        .catch(function (error) {
          if (error && error.response) {
            fulfill({ status: error.response.status, data: error.response.data });
          } else {
            reject(error);
          }
        });
    });
  }

 
}



export default RestClient;