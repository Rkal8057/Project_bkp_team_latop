const jwt = require("jsonwebtoken");
require('dotenv').config();

const UsersResource = require('../resource/user/user.resource');
const _User = new UsersResource()

module.exports = class authentication{

    async verifyToken (req, res, next) {

        const token = req.headers["authorization"]   
        if (!token) {
          return res.status(403).send({status :403,msg : "A token is required for authentication", data : false});
        }

        try {
            
            jwt.verify(token, process.env.JWT_TOKEN_KEY, async(err, decoded) => {
                if (err) {
                  return res.status(401).send({status : 401 ,msg : err.message})
                }

                req.user = await _User.getOne(decoded.user_id)

                if(req.user === null){
                    return res.status(401).send("invalid token", res, false);  
                }

                next()
            });

        } catch (err) {
            return res.status(401).send({msg: err.message, data:false} );
        }
    }; 

}


