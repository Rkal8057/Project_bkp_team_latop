const mongoose = require("mongoose");

const connectDB = 'mongodb://127.0.0.1:27017/Auth_Assignment';
mongoose.connect(connectDB, {useNewUrlParser: true, useUnifiedTopology:true})
    
mongoose.connection.on("error", err => {
    console.log("err", err)
})

mongoose.connection.on("connected", (err, res) => {
console.log("mongoose is connected")
})

const db = mongoose.connection
module.exports = db