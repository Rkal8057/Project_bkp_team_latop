const express = require("express");
const routes = express.Router();

const LogController = require('./log.controller');
const log = new LogController()

const authentication = require('../../middleware/auth')
const auth = new authentication();


routes.get('/all',auth.verifyToken, log.getAllLog)

module.exports=routes