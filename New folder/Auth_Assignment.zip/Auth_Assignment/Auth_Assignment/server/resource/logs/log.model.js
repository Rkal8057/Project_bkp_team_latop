const mongoose = require("mongoose");
Schema = mongoose.Schema

let fileSchema = new mongoose.Schema({
    userId: { 
        type: Schema.Types.ObjectId,
        ref: 'users'  
    },
    fileName: { type: String, default: '' },
    extensionType: { type: String, default: '' },
    locationPath :  {type: String, default: '' },
    description:  { type: String, default: '' },
    status : { type : String, enum :[ 'upload', 'download','delete'] },
    isDeleted :  {type: Date, default: null },
}, {timestamps : true });


File = mongoose.model('logs', fileSchema, 'logs')
module.exports = File 