const Log = require('./log.model');

module.exports= class LogResource{

    async create(data){
        console.log("LogResource@create")
        
        if(!data || data === ''){
            return new Error('data is required');
        }

        let result = await Log.create(data)
        if(!result){
            return false
        }

        return result
    }

    async getAllLog(id){
        console.log("LogResource@getAllLog")
        
        let result = await Log.find({userId : id})
        if(!result){
            return false
        }

        return result
    }
}