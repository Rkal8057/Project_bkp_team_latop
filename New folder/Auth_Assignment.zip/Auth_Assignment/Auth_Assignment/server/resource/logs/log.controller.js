
const LogResource = require('./log.resource');
const _Log = new LogResource()

module.exports = class LogController{

    async getAllLog(req, res){
        console.log("LogResource@getAllLog")

        let result  = await _Log.getAllLog(req.user._id)
        if(!result){
            return res.status(400).send({ status: 400, msg: "not found", data: flase })
        }
        return res.status(200).send({ status: 200, msg: "List of user upload file", data: result })
    } 

}