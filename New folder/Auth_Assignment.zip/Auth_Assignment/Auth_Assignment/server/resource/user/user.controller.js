const crypto = require('crypto');
const sgMail = require('@sendgrid/mail');

const UsersResource = require('./user.resource');
const _User = new UsersResource()

const LogResource = require('../logs/log.resource');
const _Log = new LogResource()

const HelperFunction = require('../../helper/helper.function');
const helperFunction = new HelperFunction()

const NodeMailerService = require('../../service/nodemailer');
const _NodeMailer = new NodeMailerService()


module.exports = class UsersController {

    async userRegister(req, res) {
        console.log("UserController@userSignup");

        let { email, password, username } = req.body
        let verificationToken = crypto.randomBytes(20).toString('hex');

        if (!email || !password) {
            return res.status(400).send({ status: 400, msg: "Email or password missing.", data: false })
        }

        let userObj = {
            username: username,
            email: email,
            password: password,
            verificationToken: verificationToken
        }

        let isCheckEmail = await _User.getByEmail(req.body.email)
        if (isCheckEmail) {
            return res.status(400).send({ status: 400, msg: "Email is already exit", data: false })
        }

        let result = await _User.create(userObj)
        if (!result) {
            return res.status(400).send({ status: 400, msg: "not create a new user", data: false })
        }

        // if (result.isVerified === false) {

        //     let verificationLink = `http://localhost:8000/user/verify?verificationToken=${verificationToken}`;
        //     let from = "sarabhaiit2@gmail.com";
        //     let subject = "Email Verification";
        //     // let html = `Click <a href="${verificationLink}">here</a> to verify your email.`;
        //     let html =`<p>Please click <a href="${verificationLink}" style="display: inline-block; padding: 10px 20px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px;">here</a> to verify your email.</p>
        //     `
        //     let mailStatus = await _NodeMailer.sendMailNodemailer(from, email, subject, html);
        //     if (!mailStatus) {
        //         return res.status(400).send({ status: 400, msg: "Email not send ", data: false })
        //     }

        // }
        return res.status(201).send({ status: 201, msg: "User registered successfully. Check your email for verification link.", data: true })
    }

    async userLogin(req, res) {
        console.log("UserController@userLogin");

        let { email, password, username } = req.body
        if (!email || !password) {
            return res.status(400).send({ status: 400, msg: "Email or password missing.", data: false })
        }

        let isCheckEmail = await _User.getByEmail(req.body.email)
        if (!isCheckEmail) {
            return res.status(400).send({ status: 400, msg: "Email address does not exist", data: false })
        }

        if (isCheckEmail.password !== password) {
            return res.status(400).send({ status: 400, msg: "Password does not match", data: false })
        }

        if (isCheckEmail.isVerified === false) {

            let verificationToken = crypto.randomBytes(20).toString('hex');
            let verificationLink = `http://localhost:8000/user/verify?verificationToken=${verificationToken}`;
            let from = "sarabhaiit2@gmail.com";
            let subject = "Email Verification";
            // let html = `Click <a href="${verificationLink}">here</a> to verify your email.`;
            let html =`<p>Please click <a href="${verificationLink}" style="display: inline-block; padding: 10px 20px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px;">here</a> to verify your email.</p>
            `
            let mailStatus = await _NodeMailer.sendMailNodemailer(from, email, subject, html);
            if (!mailStatus) {
                return res.status(400).send({ status: 400, msg: "Email not send ", data: false })
            }

            await _User.update(isCheckEmail._id , { verificationToken : verificationToken})

            return res.status(400).send({ status: 400, msg: "Email not verified. Please verify your email before logging in.", data: false })
        }

        const token = await helperFunction.tokenGenerate( { user_id: isCheckEmail._id, email : isCheckEmail.email })
        let result = await _User.update(isCheckEmail._id , { authToken : token})

        return res.status(200).send({ status: 200, msg: "Login successfully", data: result })
    }

    async verifyToken(req, res) {
        console.log("UserController@verifyToken");

        let { verificationToken } = req.query

        let checkToken = await _User.checkToken(verificationToken)
        if (!checkToken) {
            return res.status(400).send({ status: 400, msg: "Invalid verification token", data: false })
        }


        let isVerified = await _User.update(checkToken._id, { isVerified: true, verificationToken: "" })
        if (!isVerified) {
            return res.status(400).send({ status: 400, msg: "users not found", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Email is verified successfully", data: true })
    }

    async uploadPdfFile(req, res) {
        console.log("UserController@userLogin");

        if (req.file === undefined) {
            return res.status(404).send({ status: 404, msg: 'invalid request data. Please add  Pdf file only!', data: false });
        }

        let filepath = req.file.path.replace()

        // logs function
        let fileSchema = { 
            userId : req.user._id,
            fileName : req.file.originalname,
            extensionType : req.file.mimetype ,
            locationPath : req.file.path,
            status : "upload",
            description : "File upload successfully"
        }

        await _Log.create(fileSchema)

        let pdfData = await helperFunction.getPDF(filepath)
        if (!pdfData) {
            return res.status(400).send({ status: 400, msg: "Pdf file did not read", data: false });
        }

        return res.status(200).send({ status: 200, msg: "PDF data", data: pdfData })
    }
}



