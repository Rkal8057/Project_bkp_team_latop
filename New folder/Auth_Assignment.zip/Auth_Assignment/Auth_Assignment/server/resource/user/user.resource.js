const User = require('./user.model');

module.exports= class UsersResource{


    async create(data){
        console.log("UserResouce@create")
        
        if(!data || data === ''){
            return new Error('data is required');
        }

        let result = await User.create(data)
        if(!result){
            return false
        }

        return result
    }

    async getByEmail(email){
        console.log("UserResouce@getByEmail");

        if(!email || email === ''){
            return new Error('email id required');
        }

        let result = await User.findOne({ email : email })
        if(!result){
            return false
        }

        return result
    }


    async checkToken(verificationToken){
        console.log("UserResouce@checkToken");

        if(!verificationToken || verificationToken === ''){
            return new Error('verificationToken id required');
        }

        let result = await User.findOne({ verificationToken : verificationToken })
        if(!result){
            return false
        }

        return result
    }

    async update(id, data ){
        console.log("UserResouce@update")

        if(!id || id === ''){
            return new Error('data empty');
        }

        let result = await User.findByIdAndUpdate( id, data , { new : true })
        if(!result){
            return false
        }
        return result
        
    }

    async getOne(id){
        console.log("UserResouce@getOne");
        
        if(!id || id === ''){
            throw new Error('id is required');
        }

        let result = await User.findOne({ _id : id })
        if(!result){
            return false
        }

        return result
    }


}