const express = require("express");
const routes = express.Router();

const UsersController = require('./user.controller');
const user = new UsersController()

const authentication = require('../../middleware/auth')
const auth = new authentication()

const _upload = require('../../helper/upload.helper')


// simple API
routes.post('/signup',  user.userRegister);
routes.get('/verify', user.verifyToken);
routes.post('/login', user.userLogin);
routes.post('/uploads/pdf',[auth.verifyToken ,_upload.single("file")], user.uploadPdfFile)


module.exports=routes