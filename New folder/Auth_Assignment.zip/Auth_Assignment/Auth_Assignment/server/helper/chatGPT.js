const methods = {};
const { OpenAIApi } = require("openai");

methods.getAnswer = async (req) => {
    try {
        const openai = new OpenAIApi({
            apiKey: "sk-API_KEYS", // Replace with your actual API key
        });

        const data = await openai.createCompletion({
            model: "text-davinci-001",
            prompt: "hello",
        });

        return { status: 200, message: data.choices[0].text };
    } catch (e) {
        throw e;
    }
};

methods.getAnswer()

// module.exports = methods;
