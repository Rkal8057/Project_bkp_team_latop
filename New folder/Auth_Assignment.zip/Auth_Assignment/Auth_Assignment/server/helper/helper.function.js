const fs = require('fs');
const pdfParse = require('pdf-parse');
const jwt = require("jsonwebtoken")

module.exports = class HelperFunction {

  async getPDF(file) {
    console.log("HelperFunction@getPDF");

    let readFileSync = fs.readFileSync(file)
    try {
      let pdfExtract = await pdfParse(readFileSync)
      //   console.log('File content: ', pdfExtract.text)
      //   console.log('Total pages: ', pdfExtract.numpages)
      //   console.log('All content: ', pdfExtract.info)
      return pdfExtract
    } catch (error) {
      return false
    }
  }

  async tokenGenerate(data) {
    console.log("HelperFunction@tokenGenerate")

    const token = jwt.sign(data, process.env.JWT_TOKEN_KEY, { expiresIn: "2h" });
    if (!token) {
      return false
    }
    return token
  }



}

