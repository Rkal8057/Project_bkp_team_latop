const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const tournamentSchema = new Schema({
    tournament_name: {
        type: String,
        required: true
    },
    creator_name: {
        type: String,
        required: true
    },
    winner_name: {
        type: String
    },
    rooms: [{
        room_id: {
            type: String,
            required: true
        },
        players: [{
            player_name: {
                type: String,
                required: true
            },
            score: {
                type: Number,
                required: true
            }
        }]
    }]
}, { timestamps: true });

const Tournament = mongoose.model('Tournament', tournamentSchema);

module.exports = Tournament;
