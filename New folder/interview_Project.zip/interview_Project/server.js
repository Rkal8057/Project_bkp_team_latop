const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const tournamentRoutes = require('./routes/tournamentRoutes');

const app = express();
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/tournamentdb', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err.message));

// Routes
app.use('/api/tournaments', tournamentRoutes);


app.listen( 3000, ()=>{
    console.log(`Server running on port 3000`);
})


// Rahul Abhiwan
// 4:10 PM
// 1. Building a function that takes an integer array as input and moves all the 0s present in the array to the end while maintaining the relative order of the non-zero elements. You are required to implement this function in-place without making a copy of the input array.
// Input: nums = [0,1,0,3,12]

// 2. Write a program to flat an array , convert into a single array
//     Note : - without using any inbuilt function in js
//     input : -  [1, 2, 3, [4, 5, 6], [7, 8, [9, 10, 11], 12], [13, 14, 15]];
// You
// 4:27 PM
// done sir
// Rahul Abhiwan
// 4:39 PM
// const tournament = new Schema({
//     tournament_name: {
//         type: String
//     },
//     creator_name: {
//         type: String
//     },
//     winner_name:{
//         type: String
//     },
//     romms:[{
//         room_id:{
//             tyoe: String
//         },
//         players:[{
//             player_name: {
//                 type: String
//             },
//             score: {
//                 type: Number
//             }
//         }]
//     }] 

// }, {timestamps: true});
// Create a tournament and save the Tournament creator name
// Create Room
// Join Room
// Save Score of the Players
// Find the higher Player from the Room than save the name of the Winner in "winner_name"
// ivv-zsgu-ibg

// email
// hr@abhinav.com