const express = require('express');
const { tournamentCreate , createRoom ,joinRoom,saveScore,setWinner } = require('../Controller/tournamentController');
const router = express.Router();



// const tournamentController = require('../controllers/tournamentController');


// Route to create a new tournament
router.post('/create', tournamentCreate);

// Route to create a new room in the tournament
router.post('/:id/createRoom', createRoom);

// Route to join a room
router.post('/:id/joinRoom', joinRoom);

// Route to save the score of a player
router.post('/:id/saveScore', saveScore);

// Route to set the winner of the tournament
router.get('/:id/setWinner', setWinner);

module.exports = router;
