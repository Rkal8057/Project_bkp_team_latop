const express = require('express');
const Tournament = require('../Model/tournament');
const router = express.Router();

// Create a tournament
const tournamentCreate=  async(req, res) => {
    try {
        const { tournament_name, creator_name } = req.body;

        let object = {
            tournament_name: tournament_name,
            creator_name: creator_name
        }

        let result = await Tournament.create(object)
        if (!result) {
            return res.status(400).json({ message: 'Failed to create tournament' });
        }

        res.status(201).json(result);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
}



// Create a room in the tournament
const createRoom=  async (req, res) => {
    try {
        const { room_id } = req.body;

        const tournament = await Tournament.findById(req.params.id);
        if (!tournament) {
            return res.status(404).json({ message: 'Tournament not found' });
        }

        const room = { room_id: room_id, players: [] };

        const updatedTournament = await Tournament.findByIdAndUpdate(
            req.params.id,
            { $push: { rooms: room } },
            { new: true, useFindAndModify: false } 
        );

        if (!updatedTournament) {
            return res.status(404).json({ message: 'Tournament can not update' });
        }

        res.status(200).json(updatedTournament);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
}


// Join a room
const joinRoom = async (req, res) => {
    try {
        const { room_id, player_name } = req.body;

        const updatedTournament = await Tournament.findOneAndUpdate(
            { _id: req.params.id, 'rooms.room_id': room_id }, 
            { $push: { 'rooms.$.players': { player_name, score: 0 } } }, 
            { new: true, useFindAndModify: false } 
        );

        if (!updatedTournament) {
            return res.status(404).json({ message: 'Tournament or room not found' });
        }

        const room = updatedTournament.rooms.find(r => r.room_id === room_id);

        res.status(200).json(room);
    } catch (err) {
        // Handle any errors
        res.status(500).json({ error: err.message });
    }
}




// Save player score
const saveScore = async (req, res) => {
    try {
        const { room_id, player_name, score } = req.body;

        const updatedTournament = await Tournament.findOneAndUpdate(
            { _id: req.params.id, 'rooms.room_id': room_id, 'rooms.players.player_name': player_name },
            { $set: { 'rooms.$[room].players.$[player].score': score } },
            { arrayFilters: [{ 'room.room_id': room_id }, { 'player.player_name': player_name }], new: true }
        );

        if (!updatedTournament) {
            return res.status(404).json({ message: 'Tournament, room, or player not found' });
        }

        // Return the updated player information
        const room = updatedTournament.rooms.find(r => r.room_id === room_id);
        const player = room.players.find(p => p.player_name === player_name);
        res.status(200).json(player);

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
}


// Find and set winner
const setWinner=  async (req, res) => {
    try {
        const { room_id } = req.body;

        // Find the tournament and room
        const tournament = await Tournament.findOne({ _id: req.params.id, 'rooms.room_id': room_id });
        if (!tournament) return res.status(404).json({ message: 'Tournament or room not found' });

        // Find the room by room_id
        const room = tournament.rooms.find(r => r.room_id === room_id);
        if (!room || room.players.length === 0) {
            return res.status(404).json({ message: 'Room or players not found' });
        }

        // Find the player with the highest score
        const highestPlayer = room.players.reduce((prev, current) =>
            (prev.score > current.score) ? prev : current
        );

        // Update the tournament's winner_name with the highest-scoring player
        const updatedTournament = await Tournament.findByIdAndUpdate(
            req.params.id,
            { winner_name: highestPlayer.player_name },
            { new: true, useFindAndModify: false } // Return the updated tournament
        );

        // Return the winner's name
        res.status(200).json({ winner: highestPlayer.player_name });

    } catch (err) {
        // Handle any errors
        res.status(500).json({ error: err.message });
    }
}


module.exports = {
    tournamentCreate,
    createRoom,
    joinRoom,
    saveScore,
    setWinner
};