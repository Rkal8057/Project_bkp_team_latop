const express = require("express");
const routes = express.Router();

const UsersController = require('./user.controller');
const user = new UsersController()


// simple API
routes.post('/signup',  user.userRegister);
routes.post('/login', user.userLogin);
routes.get('/verify', user.verifyOtp);
routes.post('/logout',user.userLogout)


module.exports=routes