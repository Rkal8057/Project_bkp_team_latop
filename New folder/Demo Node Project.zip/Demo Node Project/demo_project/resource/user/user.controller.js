const { ObjectId } = require('mongodb');

const UsersResource = require('./user.resource');
const _User = new UsersResource()

const HelperFunction = require('../../helper/helper.function');
const helperFunction = new HelperFunction()

const NodeMailerService = require('../../service/nodemailer')
const _NodeMailer = new NodeMailerService()

const verification = require('../../emailTemplate/verificationTemplate')
const loginOtp = require('../../emailTemplate/loginTemplate')
module.exports = class UsersController {

    async userRegister(req, res) {
        console.log("UserController@userSignup");

        let { email, password, username } = req.body

        if (!email || !password) {
            return res.status(400).send({ status: 400, msg: "Email or password missing.", data: false })
        }

        let userObj = {
            username: username,
            email: email,
            password: await helperFunction.hashPassword(password),
        }
        const OTP = await helperFunction.generateRandomNumber()
        
        let isCheckEmail = await _User.getByEmail(req.body.email)
        if (isCheckEmail) {
            return res.status(400).send({ status: 400, msg: "Email is already exit", data: false })
        }
        
        let user = await _User.create(userObj)
        if (!user) {
            return res.status(400).send({ status: 400, msg: "not create a new user", data: false })
        }

        const token = await helperFunction.tokenGenerate( { user_id: user._id, email : user.email })
        let result= await _User.update(user._id, {authToken: token , otp :OTP})
        

        // add nodemailer for send the otp on mail 
        let from = process.env.SUPPORT_MAIL;
        let subject = "Please confirm your email";
        let html = await verification(OTP);
        let mailStatus = await _NodeMailer.sendMailNodemailer(from, user.email, subject, html);
        if(!mailStatus){
          return  res.status(400).send( { status : 400 , msg: 'Unable to send email OTP!', data:false });
        }

        return res.status(201).send({ status: 201, msg: "User registered successfully.", data: result })
    }

    async userLogin(req, res) {
        console.log("UserController@userLogin");

        

        let { email, password } = req.body
        if (!email || !password) {
            return res.status(400).send({ status: 400, msg: "Email or password missing.", data: false })
        }

        let isCheckEmail = await _User.getByEmail(req.body.email)
        if (!isCheckEmail) {
            return res.status(400).send({ status: 400, msg: "Email address does not exist", data: false })
        }

        let checkPassword = await helperFunction.validatePassword(password,isCheckEmail.password)
        if (!checkPassword) {
            return res.status(400).send({ status: 400, msg: "Password does not match", data: false })
        }

        const OTP = await helperFunction.generateRandomNumber()

        const token = await helperFunction.tokenGenerate( { user_id: isCheckEmail._id, email : isCheckEmail.email })
        let result= await _User.update(isCheckEmail._id, {authToken: token , otp :OTP})

        // add nodemailer for send the otp on mail         
        let from = process.env.SUPPORT_MAIL;
        let subject = "Please confirm your Login";
        let html = await loginOtp(OTP);
        let mailStatus = await _NodeMailer.sendMailNodemailer(from, email, subject, html);
        if(!mailStatus){
          return  res.status(400).send( { status : 400 , msg: 'Unable to send email OTP!', data:false });
        }

        return res.status(200).send({ status: 200, msg: "Login successfully", data: result })
    }

    async verifyOtp(req, res) {
        console.log("UserController@verifyOtp");

        let { otp } = req.body

        let checkToken = await _User.checkOtp(otp)
        if (!checkToken) {
            return res.status(400).send({ status: 400, msg: "Invalid otp", data: false })
        }

        let isVerified = await _User.update(checkToken._id, { isVerified: true, otp: "" })
        if (!isVerified) {
            return res.status(400).send({ status: 400, msg: "users not found", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Email is verified successfully", data: true })
    }

    async userLogout(req, res){
        console.log("UserController@userLogout");

        let { userId } = req.body

        if( !userId){
            return res.status(400).send({ status: 400, msg: "Data is required", data: false })
        }
       
        let result = await _User.update( new ObjectId(userId) ,{ authToken:''} )
        if (!result) {
            return res.status(400).send({ status: 400, msg: "Cann't logout", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Logout successfully", data: true })
    }
}



