const mongoose = require("mongoose")

var userSchema = new mongoose.Schema({
    username: { type: String, default: ""},
    email: { type: String, default: ""},
    password : { type: String, default: ""},
    authToken : { type: String, default: ""},
    otp : { type: String, default: ""},
    isVerified : { type: Boolean, default: false},
}, {timestamps : true });


User = mongoose.model('users', userSchema, 'users');
module.exports = User

