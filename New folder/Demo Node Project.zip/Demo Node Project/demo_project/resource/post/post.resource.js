const post = require('./post.model');

module.exports= class postResource{

    async createOne(data){
        console.log("postResource@update")

        if(!data || data === ''){
            return new Error('data empty');
        }

        let result = await post.create(data)
        if(!result){
            return false
        }
        return result
    }

    async updateOne(id, data ){
        console.log("postResource@update")

        if((!id || id === '')|| (!data || data === '')){
            return new Error('data empty');
        }

        let result = await post.findByIdAndUpdate(id, data , { new : true })
        if(!result){
            return false
        }
        return result
        
    }

    async getAll(id){
        console.log("postResource@getAll")

        if(!id || id === ''){
            return new Error('data empty');
        }
        let result = await post.find({userId :id})       
        if(!result){
            return false
        }
        return result
    }

    async deleteOne(id){
        console.log("postResource@deleteOne")

        if(!id || id === ''){
            return new Error('data empty');
        }

        let result = await post.deleteOne({_id :id})
        if(!result){
            return false
        }
        return result
    }

 
}