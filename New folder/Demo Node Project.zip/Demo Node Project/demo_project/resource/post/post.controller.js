
const { ObjectId } = require('mongodb');

const postResource = require('./post.resource');
const _post = new postResource()


module.exports = class postController {

    async createPost(req, res){
        console.log("UserController@createpost");

        let { userId , text } = req.body
        let file = req.file

        if( !userId || !text || !file){
            return res.status(400).send({ status: 400, msg: "Data is required", data: false })
        }

        let postObj ={
            userId :new ObjectId(userId),
            text : text,
            file :  process.env.BASE_URL + file.path
        }

        let result = await _post.createOne(postObj) 
        if (!result) {
            return res.status(400).send({ status: 400, msg: "Cann't create a new post", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Create a new post successfully", data: result })
    }

    async getPost(req, res){
        console.log("UserController@getpost");


        if( !req.body.userId ){
            return res.status(400).send({ status: 400, msg: "Data is required", data: false })
        }

        let result = await _post.getAll(req.body.userId)
        if (!result) {
            return res.status(400).send({ status: 400, msg: "Cann't get post list", data: false })
        }

        return res.status(200).send({ status: 200, msg: "List of post", data: result })
    }   


    async deletePost(req, res){
        console.log("UserController@deletePost");

        if( !req.body.id ){
            return res.status(400).send({ status: 400, msg: "Data is required", data: false })
        }

        let result = await _post.deleteOne(req.body.id)
        if (!result) {
            return res.status(400).send({ status: 400, msg: "Cann't delete the post", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Delete the post successfully", data: true })
    }

    async updatePost(req, res){
        console.log("UserController@updatePost");

        let { id , text } = req.body
        let file = req.file

        if( !id || !text || !file){
            return res.status(400).send({ status: 400, msg: "Data is required", data: false })
        }
       
        let postObj ={
            text : text,
            file :  process.env.BASE_URL + file.path
        }

        let result = await _post.updateOne( id ,postObj )
        if (!result) {
            return res.status(400).send({ status: 400, msg: "Cann't update the post", data: false })
        }

        return res.status(200).send({ status: 200, msg: "Update the post successfully", data: true })
    }

}



