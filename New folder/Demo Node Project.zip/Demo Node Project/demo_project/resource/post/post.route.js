const express = require("express");
const routes = express.Router();

const postController = require('./post.controller');
const post = new postController()




const _upload = require('../../helper/upload.helper')



routes.post('/create',_upload.single("file"),  post.createPost)
routes.get('/getall',  post.getPost)
routes.delete('/delete',post.deletePost)


routes.put('/update',_upload.single("file"),post.updatePost)
module.exports=routes