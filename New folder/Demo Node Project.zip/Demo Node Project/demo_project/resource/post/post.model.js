const mongoose = require("mongoose")

var postSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "users", // Reference to the User model if you have one
        required: true
    },
    file : { type: String, default : null},
    text: { type: String, default : null},
}, { timestamps: true });


post = mongoose.model('post', postSchema, 'post');
module.exports = post

