const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();
const port = 8000;
const host = 'localhost';

app.use(cors({ origin: true }));
app.use(cors()); // Add cors middleware

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('tiny'))
app.use('/uploads', express.static('uploads'));


//*******************// Database CONNECTED   //*******************//

require("./config/config");




// *******************// CONNECTED ALL ROUTES (ODM) //*******************//
const user = require('./resource/user/user.route');
app.use('/user', user);

const post = require('./resource/post/post.route');
app.use('/post', post);

//*******************// SERVER RUN ON HTTP //*******************//

var server = require('http').Server(app);
server.listen(port, () => {
    console.log(`Server is running on ${port}`);
});




