module.exports = function verification(otp) {
    return (
        `<html>
            <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
                <h2>Account Verification</h2>
                <p>Thank you for signing up! To verify your account, please use the following OTP:</p>
                <h3 style="background-color: #3498db; color: #ffffff; padding: 10px; border-radius: 5px; text-align: center;">${otp}</h3>
                <p>This OTP is valid for a limited time. Please do not share it with anyone.</p>
                <p>If you didn't sign up for this account, you can safely ignore this email.</p>
            </body>
        </html>`
    )
}