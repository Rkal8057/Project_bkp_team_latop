"use strict";
const nodemailer = require("nodemailer");
module.exports = class NodeMailerService {

    async sendMailNodemailer(from,to,subject,html){
        console.log("NodeMailerService@sendMailNodemailer")
        try{

            let transporter = await nodemailer.createTransport({

                service: 'Gmail',
                auth: {
                    user: process.env.SUPPORT_MAIL, // generated ethereal user
                    pass: process.env.PASS, // generated ethereal password
                },
            });
           
            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: from, // sender address
                to: to, // list of receivers
                subject: subject, // Subject line
                html: html, // html body
            });

            // Preview only available when sending through an Ethereal account
            console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));

            return info.messageId
        }
        catch(ex){
            console.log("Mail Status :", ex.message)
            return false
        }
    }

}