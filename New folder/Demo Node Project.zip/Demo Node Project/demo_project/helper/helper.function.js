const jwt = require("jsonwebtoken")
const bcrypt = require('bcrypt');

module.exports = class HelperFunction {

  async tokenGenerate(data) {
    console.log("HelperFunction@tokenGenerate")

    const token = jwt.sign(data, process.env.JWT_TOKEN_KEY, { expiresIn: "2h" });
    if (!token) {
      return false
    }
    return token
  }

  async generateRandomNumber() {
    return Math.floor(1000 + Math.random() * 9000); // Generates a random 4-digit number
  }

  async hashPassword(password) {
    console.log('HelperFunction@hashPassword');
    let hashedPassword = await bcrypt.hash(password, 10);

    if (!hashedPassword) {
        throw new Error('error generating password hash');
    }

    return hashedPassword;
}

async validatePassword(passwordString, passwordHash){
    console.log("HelperFunction@validatePassword")
    let isPasswordValid = await bcrypt.compare(passwordString,passwordHash)

    if(!isPasswordValid){
        return false
    }

    return true
}
}

