const multer = require("multer");
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
let directoryPath = './uploads/postFile'


const multerStorage = multer.diskStorage({
    
    destination: function (req, file, cb) {
        fs.mkdirSync(directoryPath, { recursive: true })
        cb(null, (directoryPath))
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-'+ uuidv4()+ path.basename(file.originalname)) //Appending extension
    }
});

const multerFilter = (req, file, cb) => {
    console.log("Uploadfile");

    const validFileTypes = /jpg|png|jpeg|svg/ 
    const extname = validFileTypes.test(path.extname(file.originalname).toLowerCase())
    
    if(extname === true){
        // Return true and file is saved
            return cb(null, true)
    }else{
        // Return error message if file extension does not match
        return cb(null, false, new Error('Error: pdf Only!'));
    }
  
};
  
module.exports = upload = multer({ storage: multerStorage, fileFilter: multerFilter });