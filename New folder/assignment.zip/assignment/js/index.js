const trainData = [
    { name: "Train A", route: ["CHN", "SLM", "BLR", "HYB", "NGP", "ITJ", "BPL", "AGA", "NDL"] },
    { name: "Train B", route: ["TVC", "SRR", "MAQ", "MAO", "PNE", "HYB", "NGP", "ITJ", "BPL", "PTA", "NJP", "GHY"] }
];


document.getElementById('stationForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const sourceStation = document.getElementById('source').value;
    const destinationStation = document.getElementById('destination').value;


    if (sourceStation == "HYB" || sourceStation == "NGP" || sourceStation == "ITJ" || sourceStation == "BPL" ||
        destinationStation == "HYB" || destinationStation == "NGP" || destinationStation == "ITJ" || destinationStation == "BPL"
    ) {
        const commonStations = findCommonStations(sourceStation, destinationStation, trainData);
        console.log("Common Stations between HYB and BPL:", commonStations);
        commonTrainRoute()
    }
    else {
        uniqueTrainRoute()
    }

    function findCommonStations(source, destination, trainData) {
        const commonStations = trainData.reduce((common, train) => {
            const sourceIndex = train.route.indexOf(source);
            const destIndex = train.route.indexOf(destination);

            if (sourceIndex !== -1 && destIndex !== -1 && sourceIndex < destIndex) {
                const stationsBetween = train.route.slice(sourceIndex, destIndex + 1);
                stationsBetween.forEach(station => {
                    if (!common.includes(station)) {
                        common.push(station);
                    }
                });
            }

            return common;
        }, []);

        return commonStations;
    }


    function commonTrainRoute() {

        const listContainer = document.getElementById('stationList');
        listContainer.innerHTML = ''; // Clear previous list

        const headerItem = document.createElement('li');
        headerItem.textContent = 'Trains from ' + sourceStation + ' to ' + destinationStation + ':';
        listContainer.appendChild(headerItem);

        const listItem = document.createElement('li');
        listItem.textContent = "Train AB";
        listItem.classList.add('train-item');


        // Attach a click event listener to the <li> element
        listItem.addEventListener('click', () => {
            changehtml("Train AB")
        });

        listContainer.appendChild(listItem);
    }
    
    function uniqueTrainRoute() {

        const matchingTrains = trainData.filter(train => {
            if (sourceStation === destinationStation) {
                return train.route.includes(sourceStation);
            } else {
                const sourceIndex = train.route.indexOf(sourceStation);
                const destinationIndex = train.route.indexOf(destinationStation);

                return sourceIndex !== -1 && destinationIndex !== -1 && sourceIndex < destinationIndex;
            }

        });

        const listContainer = document.getElementById('stationList');
        listContainer.innerHTML = ''; // Clear previous list

        if (matchingTrains.length > 0) {
            const headerItem = document.createElement('li');
            headerItem.textContent = 'Trains from ' + sourceStation + ' to ' + destinationStation + ':';
            listContainer.appendChild(headerItem);

            matchingTrains.forEach(train => {
                const listItem = document.createElement('li');
                listItem.textContent = train.name;
                listItem.classList.add('train-item');


                // Attach a click event listener to the <li> element
                listItem.addEventListener('click', () => {
                    changehtml(train.name)
                });

                listContainer.appendChild(listItem);
            });
        } else {
            const noTrainsItem = document.createElement('li');
            noTrainsItem.textContent = 'No trains found for the selected route.';
            listContainer.appendChild(noTrainsItem);
        }
    }
});


function changehtml(trainName) {
    if (trainName === "Train A") {
        window.location.href = 'trainA.html';
    } else if (trainName === "Train B") {
        window.location.href = 'trainB.html';
    } else if (trainName === "Train AB") {
        window.location.href = 'trainAB.html';
    }
}