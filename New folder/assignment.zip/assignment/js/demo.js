// Array of station names
const stationNames = [
    'ENGINE', 'NDL', 'NJP', 'GHY', 'KRN', 'AGA', 'PNE', 'SLM', 'MAO', 'BPL'
];

  
// Define station routes for Train 
const trainA = [0, 1, 2, 3, 4, 5];
const TrainB = [0, 1, 2, 6, 7, 8, 9];

    
// Function to get station names for a specific route
function getRouteStations(routeIndices) {
return routeIndices.map(index => stationNames[index]);
}

// Display train route
function displayTrainRoute(trainName, routeStations) {
console.log(`Train Route - ${trainName}:`);
console.log(routeStations.join(' -> '));
console.log('\n');
}
  
const trainToAssamStations = getRouteStations(trainA);
const trainToGoaStations = getRouteStations(TrainB);

// Display routes for both trains
displayTrainRoute('Assam Train', trainToAssamStations);
displayTrainRoute('Goa Train', trainToGoaStations);

  

// function moveTrainB(trainId, stationName) {
//     const train = document.getElementById(trainId);
//     console.log(trainId, stationName)
//     const stationDistances = {
//       'engine': 0,
//       "njp": 40,
//       "ghy": 80,
//       "aga": 120,
//       "pne": 160,
//       "mao": 200,
//       "bpl": 240,
//       "pta": 280,
//     };
//     const distance = stationDistances[stationName.toLowerCase()] || 0;
//     train.style.top = distance + 'px';
// }
// function moveTrainA(trainId, stationName) {
//      console.log(trainId, stationName)
//     const train = document.getElementById(trainId);
//     const stationDistances = {
//       'engine': 0,
//       'ndl': 40,
//       'krn': 80,
//       'ghy': 120,
//       'slm': 160,
//       'njp': 200,
//       'ngp': 240,
//       'blr': 280
//     };
//     const distance = stationDistances[stationName.toLowerCase()] || 0;
//     train.style.top = distance + 'px';
// }


// function moveTrain(trainId){// Get the list element by its ID
    
//     let train = document.getElementById(trainId);

//     let listItems = document.querySelectorAll('#stationList li');
//     listItems.forEach((item, index) => {
//         console.log(index, item)

//         // item.textContent = `${index}: ${item.textContent}`;
//     });

// }